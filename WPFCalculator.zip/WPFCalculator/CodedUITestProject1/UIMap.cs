﻿namespace CodedUITestProject1
{

    public partial class UIMap
    {
    }
}
